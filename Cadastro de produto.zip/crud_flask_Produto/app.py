from flask import Flask, render_template, request, url_for, redirect
from flask_sqlalchemy import SQLAlchemy
import urllib

app = Flask(__name__, template_folder='templates')
app.config['SQLALCHEMY_TRACK_MODIFICATIONS'] = True
app.config['SQLALCHEMY_DATABASE_URI'] = 'mysql://root:%s@localhost/db_hortifruit' % urllib.parse.quote_plus('pdf567!@Pp')

db = SQLAlchemy(app)

class Produtos(db.Model):
    codigo_produto = db.Column('codigo_produto', db.Integer, primary_key=True)
    nome_produto = db.Column('nome_produto', db.String(30))
    fornecedor_produto = db.Column('fornecedor_produto', db.String(30))
    peso_produto = db.Column('peso_produto', db.Numeric(10,2))
    preco_compra_produto = db.Column('preco_compra_produto', db.Numeric(10,2))
    preco_venda_produto = db.Column('preco_venda_produto', db.Numeric(10,2))

    
    def __init__(self, codigo_produto, nome_produto, fornecedor_produto, peso_produto, preco_compra_produto, preco_venda_produto):
        self.codigo_produto = codigo_produto
        self.nome_produto = nome_produto
        self.fornecedor_produto = fornecedor_produto
        self.peso_produto = peso_produto
        self.preco_compra_produto = preco_compra_produto
        self.preco_venda_produto = preco_venda_produto


@app.route('/')
def index():
    produtos = Produtos.query.all()
    return render_template('index.html', produtos=produtos)

@app.route('/add', methods=['GET', 'POST'])
def add():
    if request.method == 'POST':
        produtos = Produtos(request.form['codigo'], request.form['produto'], request.form['fornecedor'], request.form['peso'], request.form['preco_compra'], request.form['preco_venda']) 
        db.session.add(produtos)
        db.session.commit()
        return redirect(url_for('index'))
    return render_template('add.html')

@app.route('/edit/<int:codigo>', methods=['GET', 'POST'])
def edit(codigo):
    produtos = Produtos.query.get(codigo)
    if request.method == 'POST':
        produtos.codigo = request.form['codigo']
        produtos.produto = request.form['produto']
        produtos.peso = request.form['peso']
        produtos.fornecedor = request.form['fornecedor']
        produtos.preco_compra = request.form['preco_compra']
        produtos.preco_venda = request.form['preco_venda']
        db.session.commit()
        return redirect(url_for('index'))
    return render_template('edit.html', produtos=produtos)

@app.route('/delete/<int:codigo>')
def delete(codigo):
    produtos = Produtos.query.get(codigo)
    db.session.delete(produtos)
    db.session.commit()
    return redirect(url_for('index'))


if __name__ == '__main__':
    db.create_all()
    app.run(debug=True)