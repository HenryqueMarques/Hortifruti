from flask import Flask, render_template, request, url_for, redirect
from flask_sqlalchemy import SQLAlchemy
import urllib

app = Flask(__name__, template_folder='templates')
app.config['SQLALCHEMY_TRACK_MODIFICATIONS'] = True
app.config['SQLALCHEMY_DATABASE_URI'] = 'mysql://root:%s@localhost/db_hortifruit' % urllib.parse.quote_plus('pdf567!@Pp')

db = SQLAlchemy(app)

class Contas_a_pagar(db.Model):
    ct_pagar_codigo = db.Column('ct_pagar_codigo', db.Integer, primary_key=True)
    ct_pagar_documento = db.Column('ct_pagar_documento', db.Integer)
    ct_pagar_data_de_emissao = db.Column('ct_pagar_data_de_emissao', db.Date)
    ct_pagar_data_de_vencimento = db.Column('ct_pagar_data_de_vencimento', db.Date)
    ct_pagar_recebedor = db.Column('ct_pagar_recebedor', db.String(30))
    ct_pagar_categoria = db.Column('ct_pagar_categoria', db.String(30))
    ct_pagar_valor = db.Column('ct_pagar_valor', db.Numeric(10,2))
    ct_pagar_status = db.Column('ct_pagar_status', db.String(30))
    
    def __init__(self, ct_pagar_codigo, ct_pagar_documento, ct_pagar_data_de_emissao, ct_pagar_data_de_vencimento, ct_pagar_recebedor, ct_pagar_categoria, ct_pagar_valor, ct_pagar_status):
        self.ct_pagar_codigo = ct_pagar_codigo
        self.ct_pagar_documento = ct_pagar_documento
        self.ct_pagar_data_de_emissao = ct_pagar_data_de_emissao
        self.ct_pagar_data_de_vencimento = ct_pagar_data_de_vencimento
        self.ct_pagar_recebedor = ct_pagar_recebedor
        self.ct_pagar_categoria = ct_pagar_categoria
        self.ct_pagar_valor = ct_pagar_valor
        self.ct_pagar_status = ct_pagar_status



@app.route('/')
def index():
    contas_a_pagar = Contas_a_pagar.query.all()
    return render_template('index.html', contas_a_pagar=contas_a_pagar)

@app.route('/add', methods=['GET', 'POST'])
def add():
    if request.method == 'POST':
        contas_a_pagar = Contas_a_pagar(request.form['codigo'], request.form['documento'], request.form['data_emissao'], request.form['data_vencimento'], request.form['recebedor'], request.form['categoria'], request.form['valor'], request.form['status']) 
        db.session.add(contas_a_pagar)
        db.session.commit()
        return redirect(url_for('index'))
    return render_template('add.html')

@app.route('/edit/<int:codigo>', methods=['GET', 'POST'])
def edit(codigo):
    contas_a_pagar = Contas_a_pagar.query.get(codigo)
    if request.method == 'POST':
        contas_a_pagar.codigo = request.form['codigo']
        contas_a_pagar.documento = request.form['documento']
        contas_a_pagar.data_emissao = request.form['data_emissao']
        contas_a_pagar.data_vencimento = request.form['data_vencimento']
        contas_a_pagar.recebedor = request.form['recebedor']
        contas_a_pagar.categoria = request.form['categoria']
        contas_a_pagar.valor = request.form['valor']
        contas_a_pagar.status = request.form['status']
        db.session.commit()
        return redirect(url_for('index'))
    return render_template('edit.html', contas_a_pagar=contas_a_pagar)

@app.route('/delete/<int:codigo>')
def delete(codigo):
    contas_a_pagar = Contas_a_pagar.query.get(codigo)
    db.session.delete(contas_a_pagar)
    db.session.commit()
    return redirect(url_for('index'))


if __name__ == '__main__':
    db.create_all()
    app.run(debug=True)