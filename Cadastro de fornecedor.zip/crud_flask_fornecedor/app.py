from flask import Flask, render_template, request, url_for, redirect
from flask_sqlalchemy import SQLAlchemy
import urllib

app = Flask(__name__, template_folder='templates')
app.config['SQLALCHEMY_TRACK_MODIFICATIONS'] = True
app.config['SQLALCHEMY_DATABASE_URI'] = 'mysql://root:%s@localhost/db_hortifruit' % urllib.parse.quote_plus('pdf567!@Pp')

db = SQLAlchemy(app)

class Fornecedor(db.Model):
    codigo_fornecedor = db.Column('codigo_fornecedor', db.Integer, primary_key=True)
    empresa_fornecedor = db.Column('empresa_fornecedor', db.String(30))
    cnpj_fornecedor = db.Column('cnpj_fornecedor', db.Integer)
    telefone_fornecedor = db.Column('telefone_fornecedor', db.Integer)
    email_fornecedor = db.Column('email_fornecedor', db.String(30))
    endereco_rua_fornecedor = db.Column('endereco_rua_fornecedor', db.String(30))
    endereco_bairro_fornecedor = db.Column('endereco_bairro_fornecedor', db.String(30))
    endereco_numero_fornecedor = db.Column('endereco_numero_fornecedor', db.Integer)
    endereco_estado_fornecedor = db.Column('endereco_estado_fornecedor', db.String(2))
    endereco_cep_fornecedor = db.Column('endereco_cep_fornecedor', db.Integer)
    
    def __init__(self, codigo_fornecedor, empresa_fornecedor, cnpj_fornecedor, telefone_fornecedor, email_fornecedor, endereco_rua_fornecedor, endereco_bairro_fornecedor, endereco_numero_fornecedor, endereco_estado_fornecedor, endereco_cep_fornecedor):
        self.codigo_fornecedor = codigo_fornecedor
        self.empresa_fornecedor = empresa_fornecedor
        self.cnpj_fornecedor = cnpj_fornecedor
        self.telefone_fornecedor = telefone_fornecedor
        self.email_fornecedor = email_fornecedor
        self.endereco_rua_fornecedor = endereco_rua_fornecedor
        self.endereco_bairro_fornecedor = endereco_bairro_fornecedor
        self.endereco_numero_fornecedor = endereco_numero_fornecedor
        self.endereco_estado_fornecedor = endereco_estado_fornecedor
        self.endereco_cep_fornecedor = endereco_cep_fornecedor

@app.route('/')
def index():
    fornecedores = Fornecedor.query.all()
    return render_template('index.html', fornecedores=fornecedores)

@app.route('/add', methods=['GET', 'POST'])
def add():
    if request.method == 'POST':
        fornecedor = Fornecedor(request.form['codigo'], request.form['empresa'], request.form['cnpj'], request.form['telefone'], request.form['email'], request.form['rua'], request.form['bairro'], request.form['numero'], request.form['estado'], request.form['cep']) 
        db.session.add(fornecedor)
        db.session.commit()
        return redirect(url_for('index'))
    return render_template('add.html')

@app.route('/edit/<int:codigo>', methods=['GET', 'POST'])
def edit(codigo):
    fornecedor = Fornecedor.query.get(codigo)
    if request.method == 'POST':
        fornecedor.codigo = request.form['codigo']
        fornecedor.empresa = request.form['empresa']
        fornecedor.cnpj = request.form['cnpj']
        fornecedor.telefone = request.form['telefone']
        fornecedor.email = request.form['email']
        fornecedor.rua = request.form['rua']
        fornecedor.bairro = request.form['bairro']
        fornecedor.numero = request.form['numero']
        fornecedor.estado = request.form['estado']
        fornecedor.cep = request.form['cep']
        db.session.commit()
        return redirect(url_for('index'))
    return render_template('edit.html', fornecedor=fornecedor)

@app.route('/delete/<int:codigo>')
def delete(codigo):
    fornecedor = Fornecedor.query.get(codigo)
    db.session.delete(fornecedor)
    db.session.commit()
    return redirect(url_for('index'))

if __name__ == '__main__':
    db.create_all()
    app.run(debug=True)