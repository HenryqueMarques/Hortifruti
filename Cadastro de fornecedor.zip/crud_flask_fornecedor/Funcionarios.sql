Create Database db_hortifruit;

Use  db_hortifruit;

Create Table Funcionarios(
	id int PRIMARY KEY,
    username VARCHAR(30) UNIQUE,
    password VARCHAR(30),
    name VARCHAR(30),
    email VARCHAR(30) UNIQUE
);

INSERT INTO Funcionarios VALUES (1,'admin','123', 'admin', 'admin@localhost');