from flask import Flask, render_template, request, url_for, redirect
from flask_sqlalchemy import SQLAlchemy
import urllib

app = Flask(__name__, template_folder='templates')
app.config['SQLALCHEMY_TRACK_MODIFICATIONS'] = True
app.config['SQLALCHEMY_DATABASE_URI'] = 'mysql://root:%s@localhost/db_hortifruit' % urllib.parse.quote_plus('pdf567!@Pp')

db = SQLAlchemy(app)

class Contas_a_receber(db.Model):
    ct_receber_codigo = db.Column('ct_receber_codigo', db.Integer, primary_key=True)
    ct_receber_documento = db.Column('ct_receber_documento', db.Integer)
    ct_receber_data_de_emissao = db.Column('ct_receber_data_de_emissao', db.Date)
    ct_receber_data_de_vencimento = db.Column('ct_receber_data_de_vencimento', db.Date)
    ct_receber_cliente = db.Column('ct_receber_cliente', db.String(30))
    ct_receber_categoria = db.Column('ct_receber_categoria', db.String(30))
    ct_receber_valor = db.Column('ct_receber_valor', db.Numeric(10,2))
    ct_receber_status = db.Column('ct_receber_status', db.String(30))
    
    def __init__(self, ct_receber_codigo, ct_receber_documento, ct_receber_data_de_emissao, ct_receber_data_de_vencimento, ct_receber_cliente, ct_receber_categoria, ct_receber_valor, ct_receber_status):
        self.ct_receber_codigo = ct_receber_codigo
        self.ct_receber_documento = ct_receber_documento
        self.ct_receber_data_de_emissao = ct_receber_data_de_emissao
        self.ct_receber_data_de_vencimento = ct_receber_data_de_vencimento
        self.ct_receber_cliente = ct_receber_cliente
        self.ct_receber_categoria = ct_receber_categoria
        self.ct_receber_valor = ct_receber_valor
        self.ct_receber_status = ct_receber_status



@app.route('/')
def index():
    contas_a_pagar = Contas_a_receber.query.all()
    return render_template('index.html', contas_a_pagar=contas_a_pagar)

@app.route('/add', methods=['GET', 'POST'])
def add():
    if request.method == 'POST':
        contas_a_pagar = Contas_a_receber(request.form['codigo'], request.form['documento'], request.form['data_emissao'], request.form['data_vencimento'], request.form['cliente'], request.form['categoria'], request.form['valor'], request.form['status']) 
        db.session.add(contas_a_pagar)
        db.session.commit()
        return redirect(url_for('index'))
    return render_template('add.html')

@app.route('/edit/<int:codigo>', methods=['GET', 'POST'])
def edit(codigo):
    contas_a_pagar = Contas_a_receber.query.get(codigo)
    if request.method == 'POST':
        contas_a_pagar.codigo = request.form['codigo']
        contas_a_pagar.documento = request.form['documento']
        contas_a_pagar.data_emissao = request.form['data_emissao']
        contas_a_pagar.cliente = request.form['cliente']
        contas_a_pagar.categoria = request.form['categoria']
        contas_a_pagar.valor = request.form['valor']
        contas_a_pagar.status = request.form['status']
        db.session.commit()
        return redirect(url_for('index'))
    return render_template('edit.html', contas_a_pagar=contas_a_pagar)

@app.route('/delete/<int:codigo>')
def delete(codigo):
    contas_a_pagar = Contas_a_receber.query.get(codigo)
    db.session.delete(contas_a_pagar)
    db.session.commit()
    return redirect(url_for('index'))


if __name__ == '__main__':
    db.create_all()
    app.run(debug=True)