from flask import render_template, flash, redirect , url_for
from flask_login import login_manager, login_user, logout_user
from sqlalchemy.sql.base import Executable
from flask import request, abort, jsonify
from flask.wrappers import Response
from werkzeug.wrappers import json
from werkzeug.wrappers.json import JSONMixin
from app import app, db, lm

from app.models.tables import Provider, User
from app.models.forms import LoginForm

@lm.user_loader
def load_user(id):
    return User.query.filter_by(id=id).first()

@app.route("/index")
@app.route("/")
def index():
    return render_template('index.html')

@app.route("/login", methods=["GET", "POST"])
def login():
    form = LoginForm()
    if form.validate_on_submit():
        user = User.query.filter_by(username=form.username.data).first()
        if user and user.password == form.password.data:
            login_user(user)            
            flash("Logged in.")
            return redirect(url_for("index"))
        else:
            flash("Invalid login.")
            return render_template('login.html',form=form)
    else:
        print(form.errors)
    return render_template('login.html',form=form)

@app.route("/logout")
def logout():
    logout_user()
    return redirect(url_for("login"))


def gera_response(status, nome_do_conteudo, conteudo, mensagem=False):
    body = {}
    body[nome_do_conteudo] = conteudo

    if(mensagem):
        body["mensagem"] = mensagem
    return Response(json.dumps(body), status=status, mimetype="application/json")

@app.route("/cadastra-fornecedor", methods=["POST"])
def cria_fornecedor(request:request):
   body = request.get_json()

   try:
       Fornecedor = Provider(codigo = body["codigo_fornecedor"], empresa = body["empresa_fornecedor"], cnpj = body["cnpj_fornecedor"], telefone = body["telefone_fornecedor"], email = body["email_fornecedor"], rua = body["endereco_rua_fornecedor"], bairro = body["endereco_bairro_fornecedor"], numero = body["endereco_numero_fornecedor"], estado = body["endereco_estado_fornecedor"], cep = body["endereco_cep_fornecedor"])
       db.session.add(Fornecedor)
       db.session.commit()
       return gera_response(201, "Provider", Fornecedor.to_json(), "Cadastrado com sucesso!")
   except Exception as e:
        print (e)
        return gera_response(400, "Provider", {}, "Erro")