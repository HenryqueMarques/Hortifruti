from app import db

class User(db.Model):
    __tablename__ = "Funcionarios"

    id = db.Column(db.Integer, primary_key = True)
    username = db.Column(db.String(30), unique = True)
    password = db.Column(db.String(30))
    name = db.Column(db.String(30))
    email = db.Column(db.String, unique = True)

    @property
    def is_authenticated(self):
        return True

    @property
    def is_active(self):
        return True

    @property
    def is_anonymous(self):
        return False
    
    def get_id(self):
        return str(self.id)

    def __init__(self, username, password, name, email):
        self.username = username
        self.password = password
        self.name = name
        self.email = email

    def __repr__(self):
        return"<User %r>" % self.username


class Provider(db.Model):
    __tablename__ = "Fornecedor"
    
    codigo_fornecedor = db.Column(db.Integer, primary_key = True, nullable = False)
    empresa_fornecedor = db.Column(db.String(30), nullable = False)
    cnpj_fornecedor = db.Column(db.Integer, nullable = False)
    telefone_fornecedor = db.Column(db.Integer, nullable = False)
    email_fornecedor = db.Column(db.String(30), nullable = False)
    endereco_rua_fornecedor = db.Column(db.String(30), nullable = False)
    endereco_bairro_fornecedor = db.Column(db.String(30), nullable = False)
    endereco_numero_fornecedor = db.Column(db.Integer, nullable = False)
    endereco_estado_fornecedor = db.Column(db.String, nullable = False)
    endereco_cep_fornecedor = db.Column(db.Integer, nullable = False)

    @property
    def is_authenticated(self):
        return True

    @property
    def is_active(self):
        return True

    @property
    def is_anonymous(self):
        return False
    
    def get_id(self):
        return str(self.id)

    def __init__(self, codigo_fornecedor, empresa_fornecedor, cnpj_fornecedor, telefone_fornecedor, email_fornecedor, endereco_rua_fornecedor, endereco_bairro_fornecedor, endereco_numero_fornecedor, endereco_estado_fornecedor, endereco_cep_fornecedor):

        self.codigo_fornecedor = codigo_fornecedor
        self.empresa_fornecedor = empresa_fornecedor
        self.cnpj_fornecedor = cnpj_fornecedor
        self.telefone_fornecedor = telefone_fornecedor
        self.email_fornecedor = email_fornecedor
        self.endereco_rua_fornecedor = endereco_rua_fornecedor
        self.endereco_bairro_fornecedor = endereco_bairro_fornecedor
        self.endereco_numero_fornecedor = endereco_numero_fornecedor
        self.endereco_estado_fornecedor = endereco_estado_fornecedor
        self.endereco_cep_fornecedor = endereco_cep_fornecedor 