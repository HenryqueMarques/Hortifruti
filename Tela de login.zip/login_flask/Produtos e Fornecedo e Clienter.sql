use db_hortifruit;

CREATE TABLE Produtos (
codigo_produto INT NOT NULL,
nome_produto VARCHAR (30) NOT NULL,
fornecedor_produto VARCHAR (30) NOT NULL,
peso_produto DOUBLE (10,2) NOT NULL,
preco_compra_produto DOUBLE (10,2) NOT NULL,
preco_venda_produto DOUBLE (10,2) NOT NULL,
PRIMARY KEY (codigo_produto)
);

CREATE TABLE Fornecedor (
codigo_fornecedor INT NOT NULL,
empresa_fornecedor VARCHAR (30) NOT NULL,
cnpj_fornecedor INT (13) NOT NULL,
telefone_fornecedor INT (11) NOT NULL,
email_fornecedor VARCHAR (30) NOT NULL,
endereco_rua_fornecedor VARCHAR (30) NOT NULL,
endereco_bairro_fornecedor VARCHAR (30) NOT NULL,
endereco_numero_fornecedor INT (5) NOT NULL,
endereco_estado_fornecedor VARCHAR (2) NOT NULL,
endereco_cep_fornecedor INT (8) NOT NULL,
PRIMARY KEY (codigo_fornecedor)
);

CREATE TABLE Cliente (
codigo_cliente INT (5) NOT NULL,
cpf_cliente INT (11) NOT NULL,
data_nascimento_cliente DATE NOT NULL,
nome_cliente VARCHAR (30) NOT NULL,
sobrenome_cliente VARCHAR (30) NOT NULL,
endereco_rua_cliente VARCHAR (30) NOT NULL,
endereco_bairro_cliente VARCHAR (30) NOT NULL,
endereco_numero_cliente INT (5) NOT NULL,
endereco_estado_cliente VARCHAR (2) NOT NULL,
endereco_cep_cliente INT (8) NOT NULL,
PRIMARY KEY (codigo_cliente)
);

CREATE TABLE Contas_a_pagar (
ct_pagar_codigo INT (5) NOT NULL,
ct_pagar_documento INT (5) NOT NULL,
ct_pagar_data_de_emissao DATE NOT NULL,
ct_pagar_data_de_vencimento DATE NOT NULL,
ct_pagar_recebedor VARCHAR (30) NOT NULL,
ct_pagar_categoria VARCHAR (30) NOT NULL,
ct_pagar_valor DECIMAL (10,2) NOT NULL,
ct_pagar_status VARCHAR (30) NOT NULL,
PRIMARY KEY (ct_pagar_codigo)
);

CREATE TABLE Contas_a_receber(
ct_receber_codigo INT (5) NOT NULL,
ct_receber_documento INT (5) NOT NULL,
ct_receber_data_de_emissao DATE NOT NULL,
ct_receber_data_de_vencimento DATE NOT NULL,
ct_receber_cliente VARCHAR (30) NOT NULL,
ct_receber_categoria VARCHAR (30) NOT NULL,
ct_receber_valor DECIMAL (10,2) NOT NULL,
ct_receber_status VARCHAR (30) NOT NULL,
PRIMARY KEY (ct_receber_codigo)
);

Select * From Cliente;
Select * From Funcionarios;
Select * From Fornecedor;
Select * From Produtos;
Select * From Contas_a_pagar;
Select * From Contas_a_receber;