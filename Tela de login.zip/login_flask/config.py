import urllib

DEBUG = True

SQLALCHEMY_DATABASE_URI = 'mysql://root:%s@localhost/db_hortifruit' % urllib.parse.quote_plus('pdf567!@Pp')
SQLALCHEMY_TRACK_MODIFICATIONS = True

SECRET_KEY = 'chave-secreta'