from flask import Flask, render_template, request, url_for, redirect
from flask_sqlalchemy import SQLAlchemy
import urllib

app = Flask(__name__, template_folder='templates')
app.config['SQLALCHEMY_TRACK_MODIFICATIONS'] = True
app.config['SQLALCHEMY_DATABASE_URI'] = 'mysql://root:%s@localhost/db_hortifruit' % urllib.parse.quote_plus('pdf567!@Pp')

db = SQLAlchemy(app)

class Cliente(db.Model):
    codigo_cliente = db.Column('codigo_cliente', db.Integer, primary_key=True)
    cpf_cliente = db.Column('cpf_cliente', db.Integer)
    data_nascimento_cliente = db.Column('data_nascimento_cliente', db.Date)
    nome_cliente = db.Column('nome_cliente', db.String(30))
    sobrenome_cliente = db.Column('sobrenome_cliente', db.String(30))
    endereco_rua_cliente = db.Column('endereco_rua_cliente', db.String(30))
    endereco_bairro_cliente = db.Column('endereco_bairro_cliente', db.String(30))
    endereco_numero_cliente = db.Column('endereco_numero_cliente', db.Integer)
    endereco_estado_cliente = db.Column('endereco_estado_cliente', db.String(2))
    endereco_cep_cliente = db.Column('endereco_cep_cliente', db.Integer)
    
    def __init__(self, codigo_cliente, cpf_cliente, data_nascimento_cliente, nome_cliente, sobrenome_cliente, endereco_rua_cliente, endereco_bairro_cliente, endereco_numero_cliente, endereco_estado_cliente, endereco_cep_cliente):
        self.codigo_cliente = codigo_cliente
        self.cpf_cliente = cpf_cliente
        self.data_nascimento_cliente = data_nascimento_cliente
        self.nome_cliente = nome_cliente
        self.sobrenome_cliente = sobrenome_cliente
        self.endereco_rua_cliente = endereco_rua_cliente
        self.endereco_bairro_cliente = endereco_bairro_cliente
        self.endereco_numero_cliente = endereco_numero_cliente
        self.endereco_estado_cliente = endereco_estado_cliente
        self.endereco_cep_cliente = endereco_cep_cliente



@app.route('/')
def index():
    clientes = Cliente.query.all()
    return render_template('index.html', clientes=clientes)

@app.route('/add', methods=['GET', 'POST'])
def add():
    if request.method == 'POST':
        clientes = Cliente(request.form['codigo'], request.form['cpf'], request.form['data_nasc'], request.form['nome'], request.form['sobrenome'], request.form['rua'], request.form['bairro'], request.form['numero'],  request.form['estado'],  request.form['cep']) 
        db.session.add(clientes)
        db.session.commit()
        return redirect(url_for('index'))
    return render_template('add.html')

@app.route('/edit/<int:codigo>', methods=['GET', 'POST'])
def edit(codigo):
    clientes = Cliente.query.get(codigo)
    if request.method == 'POST':
        clientes.codigo = request.form['codigo']
        clientes.produto = request.form['cpf']
        clientes.peso = request.form['data_nasc']
        clientes.fornecedor = request.form['nome']
        clientes.preco_compra = request.form['sobrenome']
        clientes.preco_venda = request.form['rua']
        clientes.preco_venda = request.form['bairro']
        clientes.preco_venda = request.form['numero']
        clientes.preco_venda = request.form['estado']
        clientes.preco_venda = request.form['cep']
        db.session.commit()
        return redirect(url_for('index'))
    return render_template('edit.html', clientes=clientes)

@app.route('/delete/<int:codigo>')
def delete(codigo):
    clientes = Cliente.query.get(codigo)
    db.session.delete(clientes)
    db.session.commit()
    return redirect(url_for('index'))


if __name__ == '__main__':
    db.create_all()
    app.run(debug=True)